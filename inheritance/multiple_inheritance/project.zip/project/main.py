from project.teacher import Teacher

teacher_1 = Teacher()

print(teacher_1.get_fired())
print(teacher_1.sleep())
print(teacher_1.teach())